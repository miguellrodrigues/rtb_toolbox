import sympy as sp

g, t, h, r = sp.symbols('g t h r')
