from comau import comau_fk
from puma260 import puma260_fk
from SCARA import scara_fk
from ur3 import ur3_fk